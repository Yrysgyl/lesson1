# num = int(input(''))
# if num % 2 == 0:
#     print('четный')
# else:
#     print('нечетный')
#
# number1 = int(input(''))
# number2 = int(input(''))
#
# if number1 > number2:
#     print(number1)
# elif number1 == number2
#     print('==')
# else:
#     print(number2)
#
#
# if number2 % number1 = 0 :
#     print('yes')
#
# elif number1 % 2 = 0:
#     print('yes')
# else:
#     print('not ')

# a = int(input(''))
# b = int(input(''))
# c = int(input(''))
#
# if a == b and b == c:
#     print('равносторонний')
# elif a == b and b != c or b == c and c != a or c == a and a != b:
#     print('равнобедренным')
# else:
   # print('разностороонний')

# time = float(input('')):
# if 0 <= time <= 8:
#     print('night')
# elif 8 < time <= 10:
#     print('morning')
# elif 11 <= time <= 16:
#     print('afternoon')
# elif 16 < time < 0:
#     print('evening')
# else:
#     print('error')

# str_ch = input('')
# simvol = input('')
#
# if simvol in str_ch:
#     print('yes')
# else:
#     print('not')

# year = int(input(''))
# if year % 4 == 0:
#     print('високосный')
# elif year % 100 == 0 and year % 400 == 0:
#     print('високосный')
# else:
#     print('не високосный')

# num1 = int(input(''))
# num2 = int(input(''))
# num3 = int(input(''))
#
# if num1 < num2 and num1 < num3:
#     print(num1)
# elif num2 < num1 and num2 < num3:
#     print(num2)
# elif num3 < num1 and num3 < num2:
#     print(num3)
# else:
#     print('нельза давать 2 одинаковых числа')

# number = int(input(''))
# if number % number == 0 and number % 1 == 0 and number % 2 != 0:
#     print('простое число')
# else:
#     print('непростое число')


































































